<?php

require_once ('dbconfig.php') ;
require_once ('class.user.php') ;

$logout = new USER($DB_con);
$logout-> logout();
?>



<html>
<body>
<a href="login.php">volte ao login :)</a>
</body>
</html>

