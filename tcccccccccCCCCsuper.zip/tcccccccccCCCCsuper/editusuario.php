<?php
	
	require_once 'dbconfig.php';
	require_once 'class.user.php';
	
	$update = new USER($DB_con);

	if(isset($_GET['edit_id']) && !empty($_GET['edit_id']))
	{
		$id = $_GET['edit_id'];
		$stmt_edit = $DB_con->prepare('SELECT user_name, user_email FROM users WHERE user_id =:uid');
		$stmt_edit->execute(array(':uid'=>$id));
		$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	}
	
	
	if(isset($_POST['btn_save_updates']))
	{
		$novo_nome = $_POST['user_name'];// user name
		$novo_email = $_POST['user_email'];// user email
		
		if(!isset($errMSG))
		{
			$update -> update_user($novo_nome,$novo_email,$id);

			if($update-> update_user($novo_nome,$novo_email,$id)){
				?>
                <script>
				alert('Editado com sucesso ...');
				window.location.href='home.php';
				</script>
                <?php
			}
			else{
				$errMSG = "Opa algo deu errado !";
			}
		
		}
		
						
	}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="boostrap/dist/css/bootstrap.min.css">

<link rel="stylesheet" href="boostrap/dist/css/bootstrap-theme.min.css">

<link rel="stylesheet" href="style.css">
<script src="bootstrap/dist/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">


	<div class="page-header">
    	<h1>atualizar pinto.</h1>
    </div>

<div class="clearfix"></div>

<form method="post" enctype="multipart/form-data" class="form-horizontal">
	
    
    <?php
	if(isset($errMSG)){
		?>
        <div class="alert alert-danger">
          <span class="glyphicon glyphicon-info-sign"></span> &nbsp; <?php echo $errMSG; ?>
        </div>
        <?php
	}
	?>
   
    
	<table class="table table-bordered table-responsive">
	
    <tr>
    	<td><label class="control-label">Nome</label></td>
        <td><input class="form-control" placeholder = "coloque o novo nome" type="text" value="<?php echo $edit_row['user_name']; ?>"name="user_name" required /></td>
    </tr>
    
    <tr>
    	<td><label class="control-label">Email(e-mail).</label></td>
        <td><input class="form-control" placeholder = "coloque o novo email" type="text" value="<?php echo $edit_row['user_email']; ?>" name="user_email" required /></td>
    </tr>
        
    <tr>
        <td colspan="2"><button type="submit" name="btn_save_updates" class="btn btn-default">
        <span class="glyphicon glyphicon-save"></span> Update
        </button>
        
        <a class="btn btn-default" href="home.php"> <span class="glyphicon glyphicon-backward"></span>para cancelar clique aqui</a>
        
        </td>
    </tr>
    
    </table>
    
</form>

</div>
</body>
</html>